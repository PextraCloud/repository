# Copyright (C) 2024-2025 Pextra Inc. All rights reserved.
echo "
----------
Access the Pextra CloudEnvironment(R) web interface at:
https://$(hostname -I | awk '{print $1}'):5007
----------"