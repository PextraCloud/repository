# Web Interface
This section describes how to access and navigate the web interface of Pextra CloudEnvironment®. The web interface is the primary tool for managing your deployment, allowing you to perform various tasks, monitor system metrics, and configure settings.

> [!NOTE]
> The web interface requires a modern web browser with JavaScript enabled. It is recommended to use Mozilla Firefox or Google Chrome for the best experience.