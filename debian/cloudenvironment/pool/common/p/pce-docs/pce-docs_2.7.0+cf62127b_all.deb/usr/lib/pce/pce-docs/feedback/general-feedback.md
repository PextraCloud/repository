# General Feedback

We value your opinions about Pextra CloudEnvironment® and are committed to continuously improving our product based on user feedback. Your insights help us understand what’s working well and where we can make enhancements to better serve your needs.

## Providing General Feedback

The most effective way to share your general feedback is through our community forums:

1. Visit <a href="https://forum.pextra.cloud" title="" target="_blank">our community forum</a>.

1. Create an account or log in if you already have one.

1. Navigate to the “Feature Requests” section.

1. Click on “New Topic” to create a new post.

1. Provide a descriptive title that summarizes your feedback.

1. In the description, include:
   
   * Your overall experience with the product
   * Specific aspects you find particularly useful or challenging
   * Any suggestions for improvements
   * Context about your use case and environment
1. Submit your feedback.

## Examples of Feedback

We encourage various types of feedback, including:

* Comments on the user interface and experience

* Suggestions for improving our guides and documentation

* Reports about system performance in your environment

* Feedback on how well Pextra CloudEnvironment® works with other tools

* Overall thoughts about the product and its value

## How We Use Your Feedback

When you share your feedback:

1. Other users may respond with their own experiences or suggestions.

1. Your feedback directly influences our product roadmap and development priorities.

1. We use your insights to make incremental improvements to the product.

We appreciate you taking the time to share your thoughts with us. Your feedback is essential to helping us build a better product for all users.