# Set CockroachDB License Key

Pextra CloudEnvironment®’s highly-scalable private cloud is built on CockroachDB’s distributed architecture. The CockroachDB license key is cluster-wide (a cluster only needs one CockroachDB license key).

 > [!WARNING]
 > Pextra CloudEnvironment® will not be functional after one week (7 days) without a valid CockroachDB license key.

 > [!WARNING]
 > When a standalone node joins a cluster, it adopts the cluster’s CockroachDB license setting. Any CockroachDB license key previously set on that node is discarded.

 > [!TIP]
 > CockroachDB license keys can be obtained from <a href="https://cockroachlabs.cloud" title="" target="_blank">cockroachlabs.cloud</a>.

## Console

1. Access the node’s console through SSH or through the “Console” tab in the node view.

1. First, enter the CockroachDB console by running the following command:
   
   ````bash
   sudo cockroach sql --certs-dir=/usr/local/lib/cockroach/certs -u pextra_ce_pcedaemon
   ````

1. Set the license key by running the following command in the CockroachDB console:
   
   ````sql
   SET CLUSTER SETTING enterprise.license = '<license key here>';
   ````

1. To exit the CockroachDB console, click `CTRL+C`.

For more information, visit the <a href="https://www.cockroachlabs.com/docs/stable/licensing-faqs" title="" target="_blank">CockroachDB licensing FAQs</a>.