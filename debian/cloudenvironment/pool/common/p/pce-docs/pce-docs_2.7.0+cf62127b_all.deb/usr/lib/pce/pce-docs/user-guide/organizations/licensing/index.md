# Licensing

Pextra CloudEnvironment® uses a simple licensing model to manage access and feature availability in a multi-organization environment. Each node requires a valid, unexpired license key to operate; these licenses are aggregated at the cluster and organization levels to determine respective licensing status and edition.

 > [!TIP]
 > License keys can be purchased from the <a href="https://portal.pextra.cloud" title="" target="_blank">Pextra Customer Portal</a>. Support subscriptions are also available for purchase.