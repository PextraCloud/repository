# Starting a Stopped Instance

To bring a stopped instance back online:

1. Right-click the stopped instance.

1. Select **Power → Start**.
   
   ![Instance State Start](../images/instance-state-start.png)

1. A confirmation dialog will appear. Click **Confirm**.
   
   ![Instance State Confirm Start](../images/instance-state-confirm-start.png)

1. Wait for the instance to reach the **Running** state.

 > [!TIP]
 > Use the **Console** tab to monitor boot progress and ensure all services start correctly.