# Join Nodes to a Cluster

Clustering allows you to group multiple nodes into a single **cluster**, enabling resource sharing, redundancy, and centralized management within Pextra CloudEnvironment®.

 > [!TIP]
 > After installation, each node initially operates as a standalone cluster with one node. You can join additional nodes to an existing cluster using the join key.

 > [!WARNING]
 > When joining a cluster, standalone nodes carry over their Pextra CloudEnvironment® license key. However, the CockroachDB license key is discarded, and the node adopts the cluster’s CockroachDB license setting. Refer to the [Set CockroachDB License Key](../nodes/set-cockroachdb-license-key.md) for more information.

## Creating and Joining a Cluster

Follow these steps to join nodes into an existing cluster:

1. **Log in** directly to the node’s management interface.
   * You should see one **cluster** and one **node** listed.
1. In the **left navigation panel**, click on **Cluster**.
1. On the right-hand panel, click on the **Cluster** you want to extend.
1. Obtain the **Join Key** for that cluster.  
   ![Cluster Key](images/cluster-join.png)
1. **Copy** the join key.
1. Log in to each **new node** using its IP address and port `5007` (for example, `https://<node-ip>:5007`).
1. In the left navigation panel of each new node, click **Cluster**.
1. Click **Join Cluster**.
1. Paste the **join key** obtained earlier into the provided field and confirm the operation.
1. Return to the main cluster view.
1. You should now see the newly added node listed as a **member** of the cluster.

---

Once the process is complete, all joined nodes operate under a unified cluster, enabling centralized management of workloads, networking, and resources.