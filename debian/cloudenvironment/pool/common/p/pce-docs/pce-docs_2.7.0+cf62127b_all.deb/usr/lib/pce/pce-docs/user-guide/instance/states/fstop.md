# Force Stopping an Instance

If an instance does not respond to a normal stop:

1. Right-click the unresponsive instance.

1. Select **Power → Force Stop**.
   
   ![Instance State Force Stop](../images/instance-state-fstop.png)

1. A confirmation dialog will appear. Click **Confirm**.
   
   ![Instance State Confirm Force Stop](../images/instance-fstop-confirm.png)

1. Wait for the instance to reach the **Stopped** state.

 > [!WARNING]
 > Force stopping immediately terminates all processes. Unsaved data may be lost. Use only when a normal stop fails.