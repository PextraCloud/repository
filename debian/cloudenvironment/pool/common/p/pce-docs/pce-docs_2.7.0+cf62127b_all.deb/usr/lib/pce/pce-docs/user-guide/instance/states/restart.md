# Restarting an Instance

To reboot an instance:

1. Right-click the instance you wish to restart.

1. Select **Power → Restart**.
   
   ![Instance State Restart](../images/instance-state-restart.png)

1. A confirmation dialog will appear. Click **Confirm**.
   
   ![Instance State Restart](../images/instance-state-restart-confirm.png)

1. Wait for the instance to reach the **Running** state.

1. The instance will stop and start automatically. Use this option for applying configuration changes or recovering from transient issues.

 > [!TIP]
 > Use the **Console** tab to monitor the restart progress and ensure all services start correctly.