# Contributing

We welcome contributions to our documentation. Whether you want to fix a typo, add examples, or suggest new topics, your contributions are valuable to us. Below are the guidelines for contributing to our documentation.

## How to Contribute

### One-Click Contribution

1. If you find a typo or want to suggest an improvement, click the notepad with a pencil icon at the top right of the page:
   ![Edit this page](./images/00-edit.png)
   
   * This will take you to the GitHub page for that file.
   * If you are logged in to GitHub, you can edit the file directly in your browser. If you are not logged in, you will be prompted to log in or create an account.
1. Make your changes in the online editor.

1. Click “Propose changes” to create a pull request (PR) with your changes.
   
   * Commit your changes with a clear and descriptive commit message. We use <a href="https://www.conventionalcommits.org/en/v1.0.0/" title="" target="_blank">Conventional Commits</a> for commit messages, so please follow that format:
     ![One-click pull request](./images/01-edit-pr.png)
1. Wait for feedback from the maintainers. They may request changes or approve your PR. Once approved, your changes will be merged.

1. Celebrate your contribution! 🎉

### Full Development Setup

1. <a href="https://github.com/signup" title="" target="_blank">Create a GitHub account</a> if you don’t have one.

1. Fork the repository by clicking the “Fork” button at the top right of the page:
   ![Fork the repository](./images/02-fork.png)

1. Clone your forked repository to your local machine:
   
   ````bash
   git clone https://github.com/PextraCloud/documentation.git
   ````

1. Create a new branch for your changes:
   
   ````bash
   git switch -c <name>/<feature>
   ````

1. Set up your development environment:
   
   * Install the necessary dependencies.
   * Follow the instructions in the repository’s README for setting up your local environment.
1. Make your changes to the documentation files.
   
   * Use Markdown for formatting.
   * Follow the existing style and structure of the documentation.
1. Commit your changes with a clear and descriptive commit message. We use <a href="https://www.conventionalcommits.org/en/v1.0.0/" title="" target="_blank">Conventional Commits</a> for commit messages, so please follow that format:
   
   ````bash
   git add .
   git commit -m "fix: correct typo in installation guide"
   ````

1. Push your changes to your forked repository:
   
   ````bash
   git push origin <name>/<feature>
   ````

1. Create a pull request (PR) to the original repository:
   ![Create a pull request](./images/03-pr.png)
   
   * Navigate to <a href="https://github.com/PextraCloud/documentation" title="" target="_blank">the original documentation repository</a>.
   * Click on the “Pull Requests” tab.
   * Click on “New Pull Request.”
   * Select your branch and click “Create Pull Request.”
   * Provide a clear description of your changes and why they are needed.
1. Wait for feedback from the maintainers. They may request changes or approve your PR. Once approved, your changes will be merged.

1. Celebrate your contribution! 🎉