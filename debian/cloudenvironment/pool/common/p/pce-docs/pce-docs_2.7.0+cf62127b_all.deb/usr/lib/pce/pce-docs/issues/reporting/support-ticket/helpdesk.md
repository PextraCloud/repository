# Official Helpdesk

 > [!IMPORTANT]
 > An active support subscription is required to create a support ticket through our official helpdesk. If you would like to purchase a support subscription, please visit our <a href="https://portal.pextra.cloud" title="" target="_blank">customer portal</a>.

 > [!NOTE]
 > If you do not have an active support subscription, you can still seek help through our <a href="https://forum.pextra.cloud" title="" target="_blank">community forum</a>. See the [Community Forum](./community-forum.md) section for more details.

If you have an active support subscription, you can create a support ticket through our official helpdesk:

1. Navigate to <a href="https://helpdesk.pextra.cloud" title="" target="_blank">our helpdesk</a>.

1. Log in with your credentials.

1. Click on “Create Ticket”.

1. Complete the ticket submission form with the following information:
   
   * A clear, descriptive title
   * Detailed description of the issue
   * Steps to reproduce the issue
   * Screenshots or error messages (if applicable)
   * System information and logs (see [Collecting Logs](../collecting-logs.md))
   * Any troubleshooting steps you’ve already attempted
1. Select the appropriate priority level based on the impact to your operations.

1. Submit the ticket.

Our support team will respond according to the Service Level Agreement (SLA) associated with your support subscription level.

## Support Ticket Lifecycle

Each support ticket goes through a lifecycle, which includes the following stages:

1. **Submission**: You create and submit a ticket.

1. **Acknowledgment**: Support team acknowledges receipt.

1. **Investigation**: Support team investigates the issue.

1. **Resolution or Escalation**: Issue is either resolved or escalated to engineering.

1. **Verification**: You verify the solution works.

1. **Closure**: Ticket is closed once you confirm the issue is resolved.

 > [!TIP]
 > Check your email regularly for updates on your support ticket. The support team may request additional information or provide solutions that require your input.