# Community Forum

 > [!TIP]
 > Pextra has a dedicated support team available to assist you with any issues you may encounter. If you have an active support subscription, we recommend using the official helpdesk for the fastest response times.

If you do not have an active support subscription or prefer community-based assistance, you can post your issue on our community forum:

1. Visit <a href="https://forum.pextra.cloud" title="" target="_blank">our community forum</a>.

1. Create an account or log in if you already have one.

1. Navigate to the appropriate section (e.g., “Installation Issues,” “Configuration Help,” etc.).

1. Click on “New Topic” to create a new post.

1. Provide a clear title and detailed description of your issue.

1. Include relevant system information, logs, and any troubleshooting steps you’ve already taken.

1. Submit your post.

Our community members and Pextra staff monitor the forums regularly and will respond as soon as possible. While this option does not have a formal SLA, the community is active and helpful.