# Logging In

There are two main steps to access the web interface:

1. [Organization discovery (only applicable to multi-org deployments)](./organization-discovery.md)
1. [Authenticating with user credentials](./authentication.md)

 > [!NOTE]
 > For the web interface to function correctly, verify your user account has the necessary permissions, as outlined in the [Web Interface Permissions](./minimum-permissions.md) section.