# Verify File Integrity

 > [!NOTE]
 > This step is optional but highly recommended. Verifying the integrity of the downloaded ISO file ensures that the file came from Pextra Inc. and has not been tampered with.

Follow the instructions below for your operating system to verify the file integrity. If at any point, file integrity verification fails, do not proceed with the installation.

Before verifying GPG signatures, <a href="https://pextra.cloud/pextra-gpg-key.asc" title="" target="_blank">download our GPG public key</a>.

## Linux

Linux users can use the `sha256sum` and `gpg` commands to verify the SHA256 checksum and GPG signature of the downloaded ISO file. `sha256sum` is usually pre-installed on most Linux distributions, while `gpg` is also commonly available. If you do not have `gpg` installed, you can install it using your package manager (e.g., `apt`, `pacman`, `yum`, etc.).

### SHA256 Checksum

1. Download the SHA256 checksum file (the file that ends with `.sha256`) from the Pextra Customer Portal.
1. Open a terminal and navigate to the directory where the downloaded ISO file and SHA256 checksum file are located.
1. Calculate the SHA256 checksum of the downloaded ISO file using the following command:
   ````bash
   sha256sum pextra-ce.iso
   ````
1. Compare the output with the SHA256 checksum provided on the download page. If they match, the file is intact.

### GPG Signature

Two signatures are provided: one for the SHA256 checksum file and one for the ISO file itself. Verifying the SHA256 checksum file is sufficient and faster.

1. Download the GPG signature file (the file that ends with `.sha256.asc`) from the Pextra Customer Portal.
1. Import the Pextra Inc. GPG public key using the following command:
   ````bash
   gpg --import pextra-gpg-key.asc
   ````
1. Verify the SHA256 checksum file using the following command:
   ````bash
   gpg --verify pextra-ce.iso.sha256.asc pextra-ce.iso.sha256
   ````
1. If the output indicates that the signature is valid, the file is intact. If it indicates that the signature is not valid, do not proceed with the installation.

Verifying the ISO file itself is similar:

1. Download the GPG signature file (the file that ends with `.iso.asc`) from the Pextra Customer Portal.
1. Verify the ISO file using the following command:
   ````bash
   gpg --verify pextra-ce.iso.asc pextra-ce.iso
   ````
1. If the output indicates that the signature is valid, the file is intact. If it indicates that the signature is not valid, do not proceed with the installation.

## MacOS

MacOS users can use the `shasum` and `gpg` commands to verify the SHA256 checksum and GPG signature of the downloaded ISO file.

### SHA256 Checksum

1. Download the SHA256 checksum file (the file that ends with `.sha256`) from the Pextra Customer Portal.
1. Open a terminal and navigate to the directory where the downloaded ISO file and SHA256 checksum file are located.
1. Calculate the SHA256 checksum of the downloaded ISO file using the following command:
   ````bash
   shasum -a 256 pextra-ce.iso
   ````
1. Compare the output with the SHA256 checksum provided on the download page. If they match, the file is intact.

### GPG Signature

1. Download the GPG signature file (the file that ends with `.sha256.asc`) from the Pextra Customer Portal.
1. Import the Pextra Inc. GPG public key using the following command:
   ````bash
   gpg --import pextra-gpg-key.asc
   ````
1. Verify the SHA256 checksum file using the following command:
   ````bash
   gpg --verify pextra-ce.iso.sha256.asc pextra-ce.iso.sha256
   ````
1. If the output indicates that the signature is valid, the file is intact. If it indicates that the signature is not valid, do not proceed with the installation.

Verifying the ISO file itself is similar:

1. Download the GPG signature file (the file that ends with `.iso.asc`) from the Pextra Customer Portal.
1. Verify the ISO file using the following command:
   ````bash
   gpg --verify pextra-ce.iso.asc pextra-ce.iso
   ````
1. If the output indicates that the signature is valid, the file is intact. If it indicates that the signature is not valid, do not proceed with the installation.

## Windows

Windows users can use the `CertUtil` PowerShell command to verify the SHA256 checksum. For GPG signatures, <a href="https://gpg4win.org/" title="" target="_blank">GPG4Win</a> can be used, as Windows does not have a built-in method to verify GPG signatures. GPG4Win is free and open source software.

### SHA256 Checksum

1. Download the SHA256 checksum file (the file that ends with `.sha256`) from the Pextra Customer Portal.
1. Open PowerShell and navigate to the directory where the downloaded ISO file and SHA256 checksum file are located.
1. Calculate the SHA256 checksum of the downloaded ISO file using the following command:
   ````powershell
   CertUtil -hashfile pextra-ce.iso SHA256
   ````
1. Compare the output with the SHA256 checksum provided on the download page. If they match, the file is intact.
1. If the output does not match, do not proceed with the installation.

### GPG Signature

1. Download the latest version of <a href="https://gpg4win.org/" title="" target="_blank">GPG4Win</a> and install it.
1. Download the GPG signature file (the file that ends with `.sha256.asc`) from the Pextra Customer Portal.
1. Open PowerShell and navigate to the directory where the downloaded ISO file and GPG signature file are located.
1. Import the Pextra Inc. GPG public key using the following command:
   ````powershell
   gpg --import pextra-gpg-key.asc
   ````
1. Verify the SHA256 checksum file using the following command:
   ````powershell
   gpg --verify pextra-ce.iso.sha256.asc pextra-ce.iso.sha256
   ````
1. If the output indicates that the signature is valid, the file is intact. If it indicates that the signature is not valid, do not proceed with the installation.

Verifying the ISO file itself is similar:

1. Download the GPG signature file (the file that ends with `.iso.asc`) from the Pextra Customer Portal.
1. Verify the ISO file using the following command:
   ````powershell
   gpg --verify pextra-ce.iso.asc pextra-ce.iso
   ````
1. If the output indicates that the signature is valid, the file is intact. If it indicates that the signature is not valid, do not proceed with the installation.