# Set License Key

License keys are long-lived and typically do not need to be changed. However, if you need to change the license key, you can do so by following these steps:

 > [!NOTE]
 > The Pextra CloudEnvironment® license key is separate from the CockroachDB license key. Both must be configured. For CockroachDB steps, refer to the [Set CockroachDB License Key](./set-cockroachdb-license-key.md) section.

 > [!TIP]
 > License keys can be purchased from the <a href="https://portal.pextra.cloud" title="" target="_blank">Pextra Customer Portal</a>. Support subscriptions are also available for purchase.

## Web Interface

1. Right-click on the node in the resource tree and select **Set License Key**:
   ![Right-Click](./images/00-rightclick.png)

1. A modal will appear. The current license key along with its validity will be displayed. Enter the new license key in the text box and click **Confirm**:
   ![Set License Key](./images/01-modal.png)

1. If any errors occur, they will be displayed, otherwise, the modal will close. For example:
   ![Error](./images/02-error.png)

To confirm that the license key has been set, you can [check the licensing status of the node’s cluster](../clusters/check-licensing-status.md).