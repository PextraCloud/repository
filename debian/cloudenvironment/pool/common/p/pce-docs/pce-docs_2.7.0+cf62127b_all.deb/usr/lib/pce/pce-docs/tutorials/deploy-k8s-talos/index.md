# Deploy a Kubernetes Cluster on Talos Linux

This tutorial walks you through deploying a Kubernetes cluster running <a href="https://www.siderolabs.com/" title="" target="_blank">Talos Linux</a> on Pextra CloudEnvironment®. Talos is a minimal, immutable operating system built specifically for running Kubernetes. Every aspect of a node is managed through declarative configuration, with no SSH access required.

By the end of this tutorial you will have:

* A bootstrapped Kubernetes cluster that you can manage from your workstation with `kubectl`.
* A sample workload (nginx) deployed to verify that the cluster is operational.

## Before You Begin

**Software Requirements:**

* `talosctl`. See the <a href="https://docs.siderolabs.com/talos/latest/getting-started/talosctl" title="" target="_blank">Talos documentation</a> for installation instructions
* `kubectl`. See the <a href="https://kubernetes.io/docs/tasks/tools/#kubectl" title="" target="_blank">Kubernetes documentation</a> for installation instructions
* Standard Unix utilities

**Estimated Setup Time:**

* 30 minutes to 1 hour, depending on your familiarity with Talos and Kubernetes

## Setup Instructions

1. [Download and Deploy Talos ISO](./deploy-iso.md)
1. [Prepare Talos Node](./prepare-node.md)
1. [Generate and Apply Cluster Configuration](./generate-config.md)
1. [Bootstrap Cluster and Set Up `kubectl`](./bootstrap.md)
1. [Deploy Test Workload](./deploy-test-workload.md)