# For AI Agents

We support <a href="https://llmstxt.org/" title="" target="_blank">the /llms.txt standard</a> for providing structured context to help LLMs understand Pextra CloudEnvironment®.

The following /llms.txt files are available for use:

* [/llms.txt](llms.txt): A shorter file that provides links and metadata about the documentation.
* [/llms-full.txt](llms-full.txt): The complete documentation in a single file.