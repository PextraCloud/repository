# Supported AI Providers

The following AI providers are supported in Pextra CloudEnvironment®:

|Name|ID|Cloud-Hosted|
|----|--|------------|
|<a href="https://openai.com" title="" target="_blank">OpenAI</a>|`openai`|✅|
|<a href="https://www.anthropic.com" title="" target="_blank">Anthropic</a>|`anthropic`|✅|
|<a href="https://ai.google" title="" target="_blank">Google</a>|`google`|✅|
|<a href="https://x.ai" title="" target="_blank">xAI</a>|`xai`|✅|
|<a href="https://mistral.ai" title="" target="_blank">Mistral</a>|`mistral`|✅|
|<a href="https://deepinfra.com" title="" target="_blank">DeepInfra</a>|`deepinfra`|✅|
|<a href="https://deepseek.com" title="" target="_blank">DeepSeek</a>|`deepseek`|✅|
|<a href="https://www.cerebras.ai" title="" target="_blank">Cerebras</a>|`cerebras`|✅|
|<a href="https://groq.com" title="" target="_blank">Groq</a>|`groq`|✅|
|<a href="https://www.perplexity.ai" title="" target="_blank">Perplexity</a>|`perplexity`|✅|
|<a href="https://cohere.com" title="" target="_blank">Cohere</a>|`cohere`|✅|
|<a href="https://ollama.com" title="" target="_blank">Ollama</a>|`ollama`|❌ (self-hosted)|
|<a href="https://lmstudio.ai" title="" target="_blank">LM Studio</a>|`lmstudio`|❌ (self-hosted)|

## OpenAI-Compatible Providers

For AI providers that are OpenAI-compatible but are not explicitly listed above, use the `openai` provider type and configure a custom base URL. For more information, refer to the [Add AI Provider](./add.md#adding-openai-compatible-providers) section.