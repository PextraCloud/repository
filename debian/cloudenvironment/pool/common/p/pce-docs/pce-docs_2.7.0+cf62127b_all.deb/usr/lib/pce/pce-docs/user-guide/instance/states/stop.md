# Stopping an Instance

To gracefully stop a running instance:

1. Right-click the instance you want to stop.

1. Select **Power → Stop**.
   
   ![Instance State Stop](../images/instance-state-stop.png)

1. A confirmation dialog will appear. Click **Confirm**.
   
   ![Instance State Confirm Stop](../images/instance-state-stop-confirm.png)

1. Wait for the instance to reach the **Stopped** state.

 > [!TIP]
 > Stopping an instance shuts it down safely, allowing all processes to terminate properly. This may take a few moments depending on the workload.