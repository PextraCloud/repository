# Feature Requests

We continuously improve Pextra CloudEnvironment® based on user feedback and suggestions. If you have ideas for new features or enhancements that would improve your experience, we encourage you to share them with us.

## Submitting Feature Requests

The primary channel for submitting feature requests is through our community forums:

1. Visit <a href="https://forum.pextra.cloud" title="" target="_blank">our community forum</a>.

1. Create an account or log in if you already have one.

1. Navigate to the “Feature Requests” section.

1. Click on “New Topic” to create a new post.

1. Provide a clear, descriptive title for your feature request.

1. In the description, include:
   
   * A detailed explanation of the requested feature
   * The problem it solves or the value it provides
   * Your use case and why this feature would be beneficial
   * Any relevant examples, screenshots, or mockups (if applicable)
1. Submit your feature request.

## What Happens After Submission

After submitting your feature request:

1. **Community Discussion**: Other users may comment on your request, adding their perspectives or use cases.

1. **Feedback Collection**: Pextra team members monitor the forums and gather feature requests.

1. **Evaluation**: Our team evaluates requests based on factors such as:
   
   * Alignment with product vision
   * Number of users who would benefit
   * Technical feasibility
   * Implementation complexity
1. **Prioritization**: Approved features are prioritized in our development roadmap.

1. **Implementation**: When a feature is scheduled for development, we may reach out for additional information.