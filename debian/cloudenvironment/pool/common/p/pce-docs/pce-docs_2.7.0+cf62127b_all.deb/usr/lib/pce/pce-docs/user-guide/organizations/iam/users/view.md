# View Users

To view users within your organization:

1. In the **left navigation panel**, click your **organization name**.
1. Select **IAM** from the options.

The **Users** page displays a table listing all users in the organization.

![Users list in IAM view](../images/users-view.png)