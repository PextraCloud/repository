# Attach Volume to Instance
To attach a volume to an instance, refer to the [Attach Device](../../instance.md) section.