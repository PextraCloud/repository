# Create Volume
## Web Interface
Currently, volumes can only be created when creating a new instance, or through the Volumes API. This will change in the future.