# Gathering Diagnostic Information
