# Installation
This section provides instructions for downloading the installation ISO, and preparing it for installation. It includes steps for creating the bootable USB drives or DVD, as well as running the Pextra CloudEnvironment® installer on your server.
