# Detach Volume from Instance
To detach a volume from an instance, refer to the [Detach Device](../../instance.md) section.